Sample toolkit archive for Version 1 of the terminal scaffold.

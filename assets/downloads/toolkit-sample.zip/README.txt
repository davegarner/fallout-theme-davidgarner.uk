Sample toolkit archive for the terminal scaffold.
